//
//  ModelDic.swift
//  MultipleSelection
//
//  Created by MAC on 06/10/18.
//  Copyright © 2018 Ramneet. All rights reserved.
//

import UIKit

class ModelDic  {
        var isTrue = Bool()
        var str = String()
    
    init(dic:[Bool: String]) {
        isTrue = dic.keys.first!
        str    = dic.values.first!
    }
    
        static func getDataDic() -> [ModelDic] {
        var arrayDic = [ModelDic]()
        let d = ["1","2","3","4","5","6","7","8"]
        
        for value in d{
            let singleValue = ModelDic.init(dic: [false: value])
            arrayDic.append(singleValue)
            }
        return arrayDic
        }
}


