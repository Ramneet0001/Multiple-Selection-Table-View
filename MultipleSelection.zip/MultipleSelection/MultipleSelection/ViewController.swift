//
//  ViewController.swift
//  MultipleSelection
//
//  Created by MAC on 06/10/18.
//  Copyright © 2018 Ramneet. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var tableView: UITableView!
    var arrrayOfDic = ModelDic.getDataDic()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btn(_ sender: Any) {
        
        var a : [ModelDic] = []
        var b : [ModelDic] = []
        
       for value in arrrayOfDic{
           if value.isTrue == true{
           a.append(value)
           }else{
           b.append(value)
           }
        }
        
        for _ in 0..<b.count
        {
            let rand = Int(arc4random_uniform(UInt32(b.count)))
            let rand2 = Int(arc4random_uniform(UInt32(b.count)))
            b.swapAt(rand, rand2)
        }
        arrrayOfDic = a+b
        tableView.reloadData()
    }
    
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let singleArr = arrrayOfDic[indexPath.row]
        if singleArr.isTrue == true {
            singleArr.isTrue = false
        }else{
            singleArr.isTrue = true
        }
        
        arrrayOfDic.remove(at: indexPath.row)
        arrrayOfDic.insert(singleArr, at: 0)
        tableView.reloadData()
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as!
TableViewCell
        
        if arrrayOfDic[indexPath.row].isTrue{
        cell.lbl_string.text = arrrayOfDic[indexPath.row].str
        cell.lbl_string.textColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
        }else{
        cell.lbl_string.text = arrrayOfDic[indexPath.row].str
        cell.lbl_string.textColor = #colorLiteral(red: 0.4392156899, green: 0.01176470611, blue: 0.1921568662, alpha: 1)
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrrayOfDic.count
    }
    
    
}

